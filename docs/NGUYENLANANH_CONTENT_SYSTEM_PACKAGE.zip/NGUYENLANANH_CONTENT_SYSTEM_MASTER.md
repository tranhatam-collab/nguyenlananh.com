# NGUYENLANANH_CONTENT_SYSTEM_MASTER.md

Version: 1.0  
Status: BUILD READY  
Audience: Founder / PM / Content / Dev / Membership Ops

---

## 1. Mục tiêu hệ nội dung

Nguyenlananh.com đã có nền công khai tốt: định vị rõ, phương pháp 4 bước rõ, các trục “đi vào bên trong”, “môn học dọn dẹp”, “cái chổi”, “lao động và sự sống”, “đầu tư bản thân” đã xuất hiện rõ trên homepage và các hub công khai. Bước tiếp theo không phải là viết thêm bài rời rạc, mà là dựng **một content system có trả phí** để người đọc bước từ “được chạm” sang “được dẫn đi”.  

Hệ này phải làm được 4 việc cùng lúc:

1. Biến bài viết công khai thành điểm chạm đầu tiên.
2. Biến membership thành nơi có lộ trình, có quy trình, có thực hành, có tài liệu.
3. Biến mỗi vấn đề của thành viên thành một “đường giải quyết” có cấu trúc.
4. Tạo nền để sau 1–3 tháng mở 6 gói chuyên sâu mà không phải đập đi làm lại.

---

## 2. Triết lý sản phẩm

### 2.1. Công khai không bán đủ
Phần công khai chỉ nên làm 3 việc:
- đánh đúng nỗi đau
- định hướng đúng con đường
- kích hoạt quyết định bước vào hệ

### 2.2. Membership không phải paywall bài viết
Membership không nên được cảm nhận là “trả tiền để đọc thêm”.
Membership phải được cảm nhận là:
- có dashboard
- có lộ trình 7 / 21 / 90 ngày
- có bài tập và biểu mẫu
- có giải thích sâu hơn cho từng vấn đề
- có nơi quay lại nhiều lần

### 2.3. Premium không phải lớp sau nâng giá
6 gói chuyên sâu sau này không chỉ là “đắt hơn”.
Mỗi gói phải giải quyết một nhóm vấn đề cụ thể với:
- quy trình rõ
- bộ tài liệu riêng
- lộ trình riêng
- chỉ dấu tiến triển riêng
- demo công khai đủ mạnh để kích hoạt mua

---

## 3. Mô hình 3 tầng nội dung

## Tầng A — Public
Mục tiêu:
- chạm
- định vị
- lọc đúng người
- kéo sang /join

Định dạng:
- homepage sections
- pillar articles
- hub pages
- about / hành trình / phương pháp / chương trình
- một phần FAQ

Nguyên tắc:
- không giải quyết tới cùng
- luôn kết thúc bằng “bước tiếp”
- đủ giá trị để tin
- không đủ chi tiết để thay thế member content

## Tầng B — Member Core
Mục tiêu:
- dẫn đi
- tạo cảm giác có cấu trúc
- tạo thói quen quay lại
- giúp thành viên có kết quả sớm

Định dạng:
- onboarding
- module
- guide
- worksheet
- checklist
- journal prompt
- audio reflection / note
- weekly review
- case study
- decision tree
- FAQ theo vấn đề

Nguyên tắc:
- bài nào cũng dẫn tới hành động
- bài nào cũng có “khi nào dùng bài này”
- mỗi module phải có đầu vào / đầu ra rõ
- càng đi sâu càng phải dễ dùng

## Tầng C — Premium Tracks
Mục tiêu:
- giải quyết một vấn đề cụ thể sâu hơn
- tăng retention và ARPU
- tách nhóm nhu cầu khác nhau

Định dạng:
- curriculum theo track
- workbook riêng
- protocol riêng
- case library riêng
- office hours / hỏi đáp / ghi chú chuyên sâu
- milestone review

Nguyên tắc:
- không bán chung chung
- mô tả rõ đang giải quyết điều gì
- có demo công khai
- có “ai không phù hợp”

---

## 4. Hệ vấn đề cốt lõi phải giải

Hệ membership không nên tổ chức theo kiểu “danh mục bài viết”.
Nó phải tổ chức theo **vấn đề thành viên đang sống với**.

### 4.1. Problem clusters
1. Mắc kẹt và lặp lại
2. Quá tải, rối, không bắt đầu được
3. Môi trường sống bào mòn
4. Môi trường làm việc / ngôi nhà thứ hai làm cạn năng lượng
5. Mất dòng sáng tạo và sức sống
6. Không giữ được kỷ luật nhẹ nhưng đều
7. Không biết đầu tư cho bản thân ở đâu
8. Muốn bắt đầu lại nhưng không biết bước gì trước
9. Có nội dung, có hiểu, nhưng không chuyển thành hành động
10. Cần một nơi quay lại để không trôi mất

### 4.2. Outcome clusters
1. Rõ mình đang ở đâu
2. Có một bước nhỏ bắt đầu ngay
3. Dọn được một góc đời sống thật
4. Khôi phục nhịp sống và năng lượng
5. Giảm phân mảnh, tăng hiện diện
6. Có nguyên tắc tự dẫn đường cơ bản
7. Có lộ trình 21–90 ngày
8. Biết lúc nào nên lên track sâu hơn

---

## 5. Kiến trúc dashboard

## Route map
- /members
- /members/start
- /members/journey
- /members/library
- /members/practice
- /members/cases
- /members/resources
- /members/account
- /members/upgrade

## 5.1. /members
Mục tiêu:
- chào đón
- cho thấy “mình đã vào hệ”
- hướng người dùng tới bước đầu đúng nhất

Khối bắt buộc:
- welcome
- progress bar
- trạng thái membership + ngày hết hạn
- “Bắt đầu từ đây”
- 3 lối vào nhanh:
  - Tôi đang rất rối
  - Tôi muốn bắt đầu từ môi trường sống
  - Tôi muốn có lộ trình 90 ngày

## 5.2. /members/start
Mục tiêu:
- giảm choáng
- tạo kết quả sớm trong 30–60 phút đầu

Gồm:
- video / note chào mừng ngắn
- “đọc bài này trước”
- checklist 15 phút
- bài test tự định vị
- map 7 / 21 / 90 ngày

## 5.3. /members/journey
Hiển thị theo 3 giai đoạn:
- 7 ngày: Thấy
- 21 ngày: Gỡ
- 90 ngày: Xây

## 5.4. /members/library
Thư viện phân theo:
- module
- vấn đề
- format
- thời lượng
- access level

## 5.5. /members/practice
Các thực hành ngắn:
- 10 phút
- 20 phút
- 30 phút
- 1 tuần
- 21 ngày

## 5.6. /members/cases
Case đọc được, không cần quá dài:
- vấn đề
- bối cảnh
- sai ở đâu
- gỡ như nào
- bài học chính
- bước thử cho người đọc

## 5.7. /members/resources
Tài liệu tải:
- workbook PDF
- checklist
- weekly review
- decision sheet
- journaling template
- home reset sheet
- energy audit sheet

## 5.8. /members/upgrade
Hiển thị 6 track:
- demo
- ai phù hợp
- kết quả kỳ vọng
- nội dung gồm gì
- CTA nâng cấp

---

## 6. Cấu trúc thư viện member core

### Module 0 — Bắt đầu từ đây
Mục tiêu:
- giúp người dùng không bị ngợp
- có kết quả trong ngày đầu

Gồm:
- Welcome note
- Cách dùng hệ trong 7 phút
- Tự định vị: tôi đang ở trạng thái nào
- Checklist 24 giờ đầu
- Câu hỏi “đừng làm quá nhiều ngay”

### Module 1 — Thấy mình đang ở đâu
Mục tiêu:
- gọi tên đúng trạng thái
- giảm mù mờ

Gồm:
- Mắc kẹt trông như thế nào
- Dấu hiệu bạn đang sống bằng quán tính
- Bản đồ vòng lặp cá nhân
- Worksheet: các vòng lặp tôi đang lặp
- Reflection: mình đang chịu đựng điều gì

### Module 2 — Môi trường phản chiếu nội tâm
Mục tiêu:
- nhìn không gian sống như dữ liệu
- bắt đầu can thiệp bằng hành động thật

Gồm:
- Nhà cửa như bản đồ nội tâm
- Ngôi nhà thứ hai
- 5 dấu hiệu môi trường đang bào mòn bạn
- Checklist home reset 10 phút
- Audit: góc nào trong đời tôi đang kẹt

### Module 3 — Dọn để thấy
Mục tiêu:
- biến dọn dẹp thành thực hành nhận thức
- tránh biến nó thành mẹo decor

Gồm:
- Dọn không phải để đẹp trước tiên
- Trình tự dọn đúng: thấy → chọn → bỏ → sắp → giữ
- Vật thể, trì hoãn, tiếc nuối, sợ thiếu
- Workbook: 1 góc, 1 ngăn, 1 mặt bàn
- FAQ: dọn xong lại bừa thì sao

### Module 4 — Hành động nhỏ nhưng thật
Mục tiêu:
- chống “đọc nhiều không làm”
- khôi phục năng lực bắt đầu

Gồm:
- Vì sao bạn không bắt đầu được
- Bước nhỏ đúng khác gì bước nhỏ cho có
- Hệ 10 phút / 20 phút / 30 phút
- Daily card: hôm nay chỉ làm 1 việc
- Weekly review: điều gì đang cản

### Module 5 — Gỡ vòng lặp tiêu hao
Mục tiêu:
- nhận ra các vòng lặp tiêu hao
- thiết lập nguyên tắc chặn lại

Gồm:
- Vòng lặp trì hoãn
- Vòng lặp quá tải
- Vòng lặp tự hạ thấp giá trị
- Vòng lặp tiêu dùng để lấp
- Decision sheet: lúc nào dừng, lúc nào làm tiếp

### Module 6 — Khôi phục dòng sống và sáng tạo
Mục tiêu:
- đưa người dùng từ “tê” sang “có dòng”
- không lạm dụng ngôn ngữ bay bổng

Gồm:
- Dòng sống là gì trong đời thường
- Dòng sáng tạo không chỉ là nghệ thuật
- Hồi sinh phần sống động đã bỏ quên
- Practice: làm một việc bằng tay 20 phút
- Case: từ vô hồn đến có hơi thở

### Module 7 — Đầu tư cho chính mình đúng chỗ
Mục tiêu:
- dịch từ cảm hứng sang quyết định
- chuẩn bị cho renewal / upgrade

Gồm:
- Tiêu hao và tích lũy
- Khi nào một khoản chi thành đầu tư
- Giá trị cuộc đời bạn đáng giá bao nhiêu
- Worksheet: ngân sách nội lực
- Roadmap giá trị 12 tháng

### Module 8 — Thiết kế quỹ đạo 90 ngày
Mục tiêu:
- biến member content thành hệ sống
- kéo retention

Gồm:
- 90 ngày không để trôi
- 3 trụ tôi cần giữ
- Môi trường / nhịp sống / công việc / học tập
- Weekly scorecard
- Kế hoạch 90 ngày cá nhân

---

## 7. Hệ format nội dung

Mỗi module không chỉ có bài viết.
Phải có đủ 8 định dạng sau:

1. Deep guide  
2. Quick guide  
3. Worksheet  
4. Checklist  
5. Practice card  
6. FAQ / obstacle note  
7. Case / example  
8. Upgrade bridge

### Quy tắc
- Deep guide = hiểu sâu
- Quick guide = dùng nhanh
- Worksheet = ngồi làm
- Checklist = thực thi
- Practice card = quay lại mỗi ngày
- FAQ = giữ người dùng không rơi
- Case = tăng niềm tin
- Upgrade bridge = mở đường sang gói sâu hơn

---

## 8. Access logic

### Public
- bài pillar
- 30–40% mở đầu của bài chuyên sâu
- hub pages
- teaser của worksheets

### Member Core
- full guides
- full worksheets
- toàn bộ journey 7 / 21 / 90
- case library nền
- resources nền

### Premium
- protocol theo vấn đề
- office hours / hỏi đáp
- case khó
- templates riêng
- deeper feedback loops

---

## 9. Quy tắc viết nội dung member

1. Không giảng đạo.
2. Không mơ hồ quá mức.
3. Luôn bắt đầu từ vấn đề người đọc đang sống với.
4. Luôn có “khi nào đọc bài này”.
5. Luôn có “bước làm ngay”.
6. Luôn có “dấu hiệu đang tiến triển”.
7. Luôn có “dấu hiệu đang tự lừa mình”.
8. Luôn có CTA mềm sang bước tiếp theo.

### Template chuẩn cho một bài member
- Bài này dành cho ai
- Khi nào nên đọc
- Vấn đề thật sự là gì
- Hiểu sai phổ biến
- Cách nhìn đúng
- Bước thực hành
- Cạm bẫy thường gặp
- Dấu hiệu bạn đang tiến
- Bước tiếp

---

## 10. Gắn conversion vào content system

## 10.1. CTA trên public article
Giữa bài:
- Bạn có thể đọc tiếp. Hoặc bắt đầu đi thật.
- Mở khóa toàn bộ thực hành và worksheet từ 3 USD.

Cuối bài:
- Nếu bài này chạm, phần đi tiếp nằm trong membership.
- Vào hệ để đọc trọn, làm bài tập, và đi theo lộ trình 7 / 21 / 90 ngày.

## 10.2. CTA trong member core
Không bán quá sớm.
Chỉ bridge lên premium khi:
- người dùng đã hoàn thành ít nhất 1 module
- đang gặp vấn đề cụ thể
- hoặc đang ở cuối module 5, 6, 8

Ví dụ:
- Bạn đã thấy vòng lặp. Track “Reset & Stabilize” giúp gỡ sâu phần này.
- Bạn đã làm home reset cơ bản. Track “Environment Reset” đi sâu vào quy trình tái thiết toàn bộ không gian sống và nhịp sống.

---

## 11. 6 Premium Tracks

### Track 1 — Reset & Stabilize
Dành cho:
- người đang quá tải
- khó bắt đầu
- rối, phân mảnh, thiếu lực

Kết quả:
- ổn lại nhịp cơ bản
- giảm rối
- có nền hành động

### Track 2 — Inner Work & Loop Release
Dành cho:
- người muốn đi sâu vào vòng lặp, niềm tin, tự hạ thấp giá trị

Kết quả:
- nhìn thấy cấu trúc vô thức
- giảm lặp lại
- tăng năng lực chọn lại

### Track 3 — Environment Reset
Dành cho:
- người muốn tái thiết nhà ở, góc làm việc, ngôi nhà thứ hai, dòng sống

Kết quả:
- không gian sống bớt bào mòn
- năng lượng phục hồi
- hành vi dễ giữ hơn

### Track 4 — Discipline & Execution
Dành cho:
- người hiểu rồi nhưng không làm được đều

Kết quả:
- có nhịp
- có scorecard
- có tiến độ thật

### Track 5 — Work, Value & Money
Dành cho:
- người kẹt ở giá trị bản thân, công việc, tiền, đầu tư cho chính mình

Kết quả:
- rõ tiêu hao / tích lũy
- biết đặt tiền đúng chỗ
- bớt tự thu nhỏ mình

### Track 6 — Life Design & Long Horizon
Dành cho:
- người muốn thiết kế lại 12 tháng tới
- không chỉ chữa cháy ngắn hạn

Kết quả:
- có quỹ đạo
- có thiết kế sống
- biết mình đang đi đâu

---

## 12. Lộ trình 90 ngày cho member

### Ngày 1–7
Mục tiêu:
- không ngợp
- có kết quả đầu tiên
- thấy đúng trạng thái

Bắt buộc:
- Module 0
- 1 bài ở Module 1
- 1 practice ở Module 2
- 1 worksheet ở Module 4

### Ngày 8–21
Mục tiêu:
- gỡ bớt rối
- can thiệp vào môi trường sống và nhịp sống

Bắt buộc:
- Module 2
- Module 3
- 1 weekly review
- 1 case

### Ngày 22–45
Mục tiêu:
- nhận ra vòng lặp chính
- giữ được nhịp hành động nhỏ

Bắt buộc:
- Module 4
- Module 5
- scorecard tuần

### Ngày 46–90
Mục tiêu:
- xây trụ mới
- biết có nên vào premium hay chưa

Bắt buộc:
- Module 6
- Module 7
- Module 8
- roadmap 90 ngày

---

## 13. Cadence xuất bản

### Giai đoạn 30 ngày đầu
- 8 deep guides
- 8 worksheets
- 8 checklists
- 8 practice cards
- 4 case notes
- 4 FAQ notes
- 1 onboarding sequence
- 1 roadmap 90 ngày

### Giai đoạn 60–90 ngày
- hoàn thiện 8 modules đủ 8 format
- mở demo 2 premium tracks đầu
- bắt đầu office hours / transcript / Q&A note

---

## 14. CMS model

### Bảng content_items
- id
- slug
- title
- summary
- access_level (public/member/premium)
- content_type (guide/worksheet/checklist/case/faq/practice/audio/pdf)
- module
- problem_cluster
- outcome_cluster
- duration_estimate
- difficulty
- prerequisite
- hero_image
- status
- published_at
- updated_at
- renewal_relevant (boolean)
- upgrade_track_hint

### Bảng journeys
- id
- journey_name
- day_range
- item_order
- content_item_id

### Bảng resources
- id
- title
- file_url
- access_level
- related_module

---

## 15. Quy trình sản xuất nội dung

1. Chọn problem cluster
2. Viết deep guide
3. Tách ra quick guide
4. Làm worksheet
5. Làm checklist
6. Viết FAQ / obstacle note
7. Gắn case
8. Gắn CTA sang bước tiếp
9. Gắn tags + access level
10. QA: dùng được chưa, hay chỉ hay chữ

---

## 16. KPI nội dung

### Public
- CTR sang /join
- scroll depth
- number of related article clicks

### Member
- Day 1 activation
- completion rate module 0
- return within 7 days
- worksheet download/use
- journey completion 21 days

### Premium
- upgrade rate from module 5 / 6 / 8
- retention 90 days
- renewal rate year 2

---

## 17. Ưu tiên build trong hôm nay

### Dev
- routes members
- access levels
- library filter
- resources area
- article CTA component
- paywall block component

### Content
- Module 0
- Module 1
- Module 2
- Module 4
- 1 worksheet each
- 1 practice each
- 1 FAQ each

### Design
- dashboard cards
- worksheet style
- CTA blocks
- upgrade cards

---

## 18. Kết luận

Content system này phải khiến người dùng cảm thấy:

“Tôi không chỉ vào đây để đọc thêm. Tôi vào đây để được dẫn đi.”

Nếu làm đúng:
- public site chạm và lọc
- membership giữ người và tạo kết quả
- premium giải quyết sâu và tạo doanh thu bền

---
END
