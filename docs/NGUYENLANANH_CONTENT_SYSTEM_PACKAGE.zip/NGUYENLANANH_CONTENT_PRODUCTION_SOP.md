# NGUYENLANANH_CONTENT_PRODUCTION_SOP.md

Version: 1.0  
Status: OPERATING DOCUMENT

---

## 1. Quy trình sản xuất chuẩn cho 1 nội dung member

### Bước 1 — Xác định vấn đề
Mỗi nội dung phải trả lời rõ:
- người này đang mắc ở đâu
- cảm giác họ đang có là gì
- họ cần hiểu thêm hay cần làm ngay

### Bước 2 — Chọn format
Không phải vấn đề nào cũng cần deep guide.
- nếu người dùng đang rối: checklist / practice trước
- nếu người dùng chưa gọi tên được vấn đề: deep guide trước
- nếu người dùng đọc nhiều không làm: worksheet / daily card trước

### Bước 3 — Viết bản nền
Template:
- Bài này dành cho ai
- Khi nào nên đọc
- Vấn đề là gì
- Hiểu sai phổ biến
- Cách nhìn đúng
- Bước làm ngay
- Cạm bẫy
- Dấu hiệu tiến triển
- Bước tiếp

### Bước 4 — Tách asset phụ
Từ deep guide phải tách ra:
- 1 worksheet
- 1 checklist hoặc practice
- 1 FAQ note
- 1 CTA block

### Bước 5 — Gắn metadata
- access level
- module
- problem cluster
- outcome cluster
- duration
- prerequisite
- upgrade hint

### Bước 6 — QA
Checklist:
- có dùng được không
- có bước làm ngay không
- có quá mơ hồ không
- có biến thành bài public kéo dài không
- có dẫn tới nội dung kế tiếp không

---

## 2. Nhịp xuất bản đề xuất

### Hằng tuần
- 1 deep guide
- 1 worksheet
- 1 practice card
- 1 FAQ / obstacle note

### Hằng tháng
- 1 case note
- 1 resource mới
- 1 cập nhật roadmap
- 1 upgrade demo piece

---

## 3. Vai trò team

### Founder / lead content
- khóa insight
- duyệt giọng
- duyệt logic hành trình
- không viết tất cả mọi thứ nếu không cần

### Editor / content architect
- map module
- giữ consistency
- tách format
- kiểm soát không trùng public content

### Ops
- nhập CMS
- gắn tags
- lịch publish
- kiểm tra internal links

### Design
- worksheet
- dashboard cards
- CTA blocks
- PDF templates

### Dev
- access control
- library filters
- completion states
- download tracking
- upgrade triggers

---

## 4. Quy tắc tránh lỗi

1. Không đưa hết “đáp án” vào bài public.
2. Không để member content toàn chữ dài.
3. Không viết bài mà không có bước làm ngay.
4. Không để premium track chỉ là gộp lại vài bài member.
5. Không publish khi chưa gắn module + tags + CTA.
6. Không để 2 nội dung nói cùng một thứ bằng 2 tiêu đề khác nhau.

---

## 5. Definition of Done

Một nội dung chỉ được coi là xong khi:
- có title
- có slug
- có summary
- có access level
- có problem cluster
- có outcome cluster
- có CTA
- có step tiếp theo
- có ít nhất 1 asset phụ nếu là deep guide

---
END
