# NGUYENLANANH_PREMIUM_TRACKS_BLUEPRINT.md

Version: 1.0  
Status: PHASE 2 READY

---

## 1. Mục tiêu 6 tracks

6 tracks không nên mở cùng lúc để “cho nhiều”.
Nên mở theo thứ tự:

1. Reset & Stabilize
2. Environment Reset
3. Inner Work & Loop Release
4. Discipline & Execution
5. Work, Value & Money
6. Life Design & Long Horizon

---

## 2. Blueprint từng track

## Track 1 — Reset & Stabilize
Giải cho:
- quá tải
- phân mảnh
- không làm nổi gì
- đang rối

Gồm:
- map trạng thái khẩn cấp
- nhịp 7 ngày ổn lại
- protocol giảm quá tải
- sheet dừng rò rỉ năng lượng
- checklist self-stabilization

Demo công khai:
- 5 dấu hiệu bạn không chỉ “mệt” mà đang rối hệ

## Track 2 — Environment Reset
Giải cho:
- nhà cửa bào mòn
- góc làm việc không đỡ nổi
- ngôi nhà thứ hai tiêu hao

Gồm:
- audit toàn bộ không gian
- protocol tái thiết 14 ngày
- zone map
- declutter logic
- office / work corner reset

Demo công khai:
- 5 dấu hiệu không gian đang làm cạn bạn mỗi ngày

## Track 3 — Inner Work & Loop Release
Giải cho:
- vòng lặp
- phản xạ cũ
- tự hạ thấp giá trị
- dính vào bản sắc cũ

Gồm:
- portrait niềm tin lõi
- loop map
- trigger journal
- reframe sheet
- protocol tách mình khỏi vòng lặp

Demo công khai:
- tại sao bạn biết rồi vẫn lặp lại

## Track 4 — Discipline & Execution
Giải cho:
- hiểu mà không làm
- không đều
- hay bỏ dở

Gồm:
- nhịp cá nhân 28 ngày
- scorecard
- friction removal sheet
- anti-collapse protocol
- weekly reset

Demo công khai:
- kỷ luật nhẹ nhưng đều trông như thế nào

## Track 5 — Work, Value & Money
Giải cho:
- không dám đầu tư cho mình
- làm việc dưới giá trị
- kẹt ở tiền và tự định giá

Gồm:
- value audit
- pricing self-worth map
- tiêu hao / tích lũy / đầu tư
- money avoidance map
- 12-month capacity sheet

Demo công khai:
- điều bạn thiếu không phải chỉ là tiền

## Track 6 — Life Design & Long Horizon
Giải cho:
- không biết đang đi đâu
- sống phản ứng
- muốn thiết kế lại 12 tháng tới

Gồm:
- 12-month map
- 4 trụ cuộc sống
- annual review / reset
- horizon design workbook
- long-game scorecard

Demo công khai:
- mình đang đi con đường gì

---
END
