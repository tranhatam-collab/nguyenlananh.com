# NGUYENLANANH_MEMBER_ONBOARDING_90_DAYS.md

Version: 1.0  
Status: BUILD READY

---

## 1. Mục tiêu onboarding

Onboarding không phải “giới thiệu hệ thống”.
Onboarding phải làm 3 việc:
1. giảm choáng
2. tạo kết quả sớm
3. tạo thói quen quay lại

---

## 2. Giai đoạn 24 giờ đầu

### Thành viên cần làm
- mở dashboard
- đọc welcome
- làm bài tự định vị
- chọn 1 lối vào:
  - Tôi đang rất rối
  - Tôi muốn bắt đầu từ môi trường sống
  - Tôi muốn có lộ trình 90 ngày

### Kết quả kỳ vọng
- không bị ngợp
- thấy hệ này có đường đi
- làm xong ít nhất 1 practice 10 phút

---

## 3. 7 ngày đầu

### Day 1
- Welcome
- Tự định vị hiện trạng
- Checklist 24 giờ đầu

### Day 2
- Mắc kẹt trông như thế nào
- Bản đồ vòng lặp cá nhân

### Day 3
- Nhà cửa như bản đồ nội tâm
- Home reset 10 phút

### Day 4
- Vì sao bạn không bắt đầu được
- Hôm nay chỉ 1 việc

### Day 5
- Dòng sống là gì trong đời thường
- Làm một việc bằng tay 20 phút

### Day 6
- Tiêu hao và tích lũy
- Worksheet: ngân sách nội lực

### Day 7
- Weekly review số 1
- Chọn 1 trụ muốn giữ trong tuần tới

---

## 4. Ngày 8–21

Mục tiêu:
- chạm vào môi trường sống
- gỡ một vòng lặp rõ nhất
- bắt đầu nhịp hành động nhỏ

### Tuần 2
- Ngôi nhà thứ hai
- Audit không gian sống
- Dọn không phải để đẹp trước tiên
- 1 góc 1 ngăn 1 mặt bàn

### Tuần 3
- Vòng lặp trì hoãn
- Vòng lặp quá tải
- Decision sheet
- Weekly review số 2

### Kết quả kỳ vọng
- người dùng không còn cảm giác chỉ đọc
- đã đụng tay vào không gian sống thật
- đã gọi tên ít nhất 1 vòng lặp

---

## 5. Ngày 22–45

Mục tiêu:
- duy trì nhịp
- không để rơi lại quán tính cũ

### Nội dung
- Bước nhỏ đúng
- Nhịp 10-20-30
- Daily card
- FAQ: biết nhưng không làm
- Case nền

### Kết quả kỳ vọng
- có nhịp tối thiểu 5 ngày / tuần
- giảm áp lực “phải làm lớn”

---

## 6. Ngày 46–90

Mục tiêu:
- xây trụ mới
- nhìn dài hạn
- mở cánh cửa renewal / upgrade

### Nội dung
- Dòng sáng tạo không chỉ là nghệ thuật
- Những gì đang làm tôi khô lại
- Khi nào một khoản chi thành đầu tư
- 3 trụ tôi cần giữ
- Kế hoạch 90 ngày cá nhân

### Kết quả kỳ vọng
- có plan 90 ngày
- biết mình cần track sâu nào
- tăng khả năng renewal

---

## 7. Trigger nâng cấp

Chỉ hiển thị mạnh khi:
- người dùng hoàn thành 30% nội dung nền
- người dùng tải ít nhất 2 worksheet
- hoặc người dùng quay lại 3 tuần liên tiếp

### Trigger copy
- Bạn đã thấy vấn đề. Giờ là lúc đi sâu vào phần gốc.
- Bạn đã làm phần nền. Track này giúp bạn giải sâu hơn vấn đề đang kẹt nhất.
- Bạn không cần bắt đầu lại từ đầu. Bạn cần một lớp sâu hơn.

---

## 8. Metrics theo giai đoạn

### 24 giờ đầu
- mở dashboard
- click “bắt đầu từ đây”
- hoàn thành tự định vị

### 7 ngày
- hoàn thành ít nhất 3 nội dung
- làm ít nhất 1 practice
- quay lại ít nhất 2 lần

### 21 ngày
- hoàn thành 1 worksheet môi trường sống
- hoàn thành 1 weekly review

### 90 ngày
- có plan 90 ngày
- có điểm số progress
- renewal intent / upgrade intent

---
END
